import 'package:flutter/material.dart';
import 'package:week3/article.dart';

import 'details_news_screen.dart';

class NewScreen extends StatelessWidget {
  static const routeName = '/news_list';
  const NewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('News App'),
      ),
      body: FutureBuilder<String>(
        future: DefaultAssetBundle.of(context).loadString('news.json'),
        builder:(context, snapshot){
          final List<Article> articles = parseArticles(snapshot.data);
          return ListView.builder(
            itemCount: articles.length,
            itemBuilder: (context, index){
              return buildItem(context, articles[index]);
            }
          );
        },
      ),
    );
  }

  Widget buildItem(BuildContext context, Article article) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Image.network(article.urlToImage),
      title: Text(article.title),
      subtitle: Text(article.description),
      onTap: () {
        Navigator.pushNamed(context, DetailNewScreen.routeName, arguments: article);
      },
    );
  }
}


