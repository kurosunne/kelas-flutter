import 'package:flutter/material.dart';
import 'package:week3/article.dart';
import 'package:week3/kdrama.dart';

import 'details_news_screen.dart';

class NewScreen extends StatelessWidget {
  static const routeName = '/kdrama_list';
  const NewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kdrama App'),
      ),
      body: ListView.builder(
          itemCount: KoreanDramaList.length,
          itemBuilder: (context,index){
            final KoreanDrama kdrama = KoreanDramaList[index];
            return InkWell(
              onTap: (){

              },
              child: Card(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: Image.network(kdrama.banner),
                    ),
                  ],
                ),
              ),
            );
          },
      )
    );
  }

  Widget buildItem(BuildContext context, Article article) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: Image.network(article.urlToImage),
      title: Text(article.title),
      subtitle: Text(article.description),
      onTap: () {
        Navigator.pushNamed(context, DetailNewScreen.routeName, arguments: article);
      },
    );
  }
}


