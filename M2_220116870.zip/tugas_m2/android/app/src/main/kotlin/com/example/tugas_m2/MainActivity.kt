package com.example.tugas_m2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
